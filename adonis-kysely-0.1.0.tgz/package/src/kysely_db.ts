import { ControlledTransaction, Kysely } from 'kysely'
import { v7 as randomUUID } from 'uuid'

import type { AdonisKyselyConfig } from '#src/types/main'
import type { DB } from 'adonis-kysely/types/db'

import { ApplicationService, LoggerService } from '@adonisjs/core/types'
import { TransactionContext } from '#src/transaction_context'

export class AdonisKyselyDB {
  #kyselyDB: Kysely<DB>
  #app: ApplicationService
  #logger: LoggerService
  #options: AdonisKyselyConfig

  #trxContext: TransactionContext
  #globalTestTransactionId: string | null = null
  constructor(
    app: ApplicationService,
    logger: LoggerService,
    options: AdonisKyselyConfig,
    trxContext: TransactionContext
  ) {
    this.#app = app
    this.#logger = logger
    this.#options = options
    this.#trxContext = trxContext

    this.#kyselyDB = new Kysely<DB>({
      dialect: options.dialect,
      log: options.log,
    })
  }

  getContext() {
    return this.#trxContext
  }

  private isTestMode() {
    if (this.#options.advanced.bypass_test_security) return false
    return this.#app.inTest
  }

  getConnexion(): Kysely<DB> | ControlledTransaction<DB> {
    const allTransactions = this.#trxContext.getAllTransactions()

    if (this.isTestMode() && allTransactions.size === 0 && !this.#globalTestTransactionId) {
      throw Error(
        '[AdonisKysely] You cannot access to the database without transaction in test mode'
      )
    }

    // First check AsyncLocalStorage context (highest priority)
    const currentTrxId = this.#trxContext.get()
    if (currentTrxId) {
      const trx = this.#trxContext.getTransaction(currentTrxId)
      if (trx) {
        this.#logger.debug(`[AdonisKysely] Using AsyncLocalStorage transaction: ${currentTrxId}`)
        return trx
      } else {
        this.#logger.warn(
          `[AdonisKysely] Transaction ${currentTrxId} found in context but not in transactions map`
        )
      }
    }

    // In test mode, fall back to global test transaction if available
    if (this.isTestMode() && this.#globalTestTransactionId) {
      const testTrx = this.#trxContext.getTransaction(this.#globalTestTransactionId)
      if (testTrx) {
        this.#logger.debug(
          `[AdonisKysely] Using global test transaction: ${this.#globalTestTransactionId}`
        )
        return testTrx
      } else {
        this.#logger.warn(
          `[AdonisKysely] Global test transaction ${this.#globalTestTransactionId} not found in transactions map`
        )
      }
    }

    this.#logger.debug('[AdonisKysely] Using direct database connection (no transaction)')
    return this.#kyselyDB
  }

  async startTransaction(): Promise<string> {
    const id = randomUUID()

    // In test mode, prioritize global test transaction for nesting
    let parentTrx: ControlledTransaction<DB> | null = null
    let parentTrxId: string | null = null

    // First check AsyncLocalStorage context
    const currentTrxId = this.#trxContext.get()
    if (currentTrxId) {
      parentTrx = this.#trxContext.getTransaction(currentTrxId) || null
      parentTrxId = currentTrxId
    }

    // In test mode, if no AsyncLocalStorage context but global test transaction exists, use it as parent
    if (!parentTrx && this.isTestMode() && this.#globalTestTransactionId) {
      parentTrx = this.#trxContext.getTransaction(this.#globalTestTransactionId) || null
      parentTrxId = this.#globalTestTransactionId
    }

    if (parentTrx && parentTrxId) {
      // Nested transaction using savepoint
      const nestedTrx = await parentTrx.startTransaction().execute()
      this.#trxContext.setTransaction(id, nestedTrx)
      this.#logger.info(`[AdonisKysely] Started nested transaction ${id} (parent: ${parentTrxId})`)
    } else {
      // Root transaction
      const rootTrx = await this.#kyselyDB.startTransaction().execute()
      this.#trxContext.setTransaction(id, rootTrx)
      this.#logger.info(`[AdonisKysely] Started root transaction ${id}`)
    }

    return id
  }

  async commitTransaction(id?: string) {
    if (this.isTestMode()) {
      this.#logger.debug('[AdonisKysely] Skipping commit in test mode')
      return
    }

    const parentTrxId = this.#trxContext.get()
    const trxId = id || parentTrxId
    if (!trxId) {
      this.#logger.warn('[AdonisKysely] No transaction to commit')
      return
    }

    const trx = this.#trxContext.getTransaction(trxId)
    if (!trx) {
      this.#logger.warn(`[AdonisKysely] Transaction ${trxId} not found`)
      return
    }

    try {
      await trx.commit().execute()
      this.#logger.info(`[AdonisKysely] Committed transaction ${trxId}`)
    } catch (err: any) {
      this.#logger.error(`[AdonisKysely] Failed to commit transaction ${trxId}: ${err.message}`)
      throw err
    } finally {
      this.#trxContext.removeTransaction(trxId)
    }
  }

  async rollbackTransaction(id?: string) {
    const parentTrxId = this.#trxContext.get()
    const trxId = id || parentTrxId
    if (!trxId) {
      this.#logger.warn('[AdonisKysely] No transaction to rollback')
      return
    }

    const trx = this.#trxContext.getTransaction(trxId)
    if (!trx) {
      this.#logger.warn(`[AdonisKysely] Transaction ${trxId} not found`)
      return
    }

    try {
      await trx.rollback().execute()
      this.#logger.info(`[AdonisKysely] Rolled back transaction ${trxId}`)
    } catch (err: any) {
      this.#logger.error(`[AdonisKysely] Failed to rollback transaction ${trxId}: ${err.message}`)
      throw err
    } finally {
      this.#trxContext.removeTransaction(trxId)
    }
  }

  async runInTransaction<T>(callback: () => Promise<T>): Promise<T> {
    const id = await this.startTransaction()
    try {
      const result = await this.#trxContext.run(id, callback)
      await this.commitTransaction(id)
      return result
    } catch (err) {
      await this.rollbackTransaction(id)
      throw err
    }
  }

  getTransaction(id: string) {
    const transaction = this.#trxContext.getTransaction(id)
    if (!transaction) return null

    return transaction
  }

  listTransaction() {
    return Array.from(this.#trxContext.getAllTransactions().keys())
  }

  async rollbackAll() {
    const allTransactions = this.#trxContext.getAllTransactions()

    const transactionIds = Array.from(allTransactions.keys()).slice().reverse()

    for (const id of transactionIds) {
      await this.rollbackTransaction(id)
    }
  }

  setGlobalTestTransaction(transactionId: string) {
    if (this.isTestMode()) {
      this.#globalTestTransactionId = transactionId
      this.#logger.debug(`[AdonisKysely] Set global test transaction: ${transactionId}`)
    }
  }

  clearGlobalTestTransaction() {
    if (this.isTestMode()) {
      this.#globalTestTransactionId = null
      this.#logger.debug('[AdonisKysely] Cleared global test transaction')
    }
  }

  async destroy() {
    try {
      await this.rollbackAll()
      await this.#kyselyDB.destroy()
      this.#logger.info('[AdonisKysely] Database connection destroyed')
    } catch (err: any) {
      this.#logger.error(`[AdonisKysely] Failed to destroy DB: ${err.message}`)
    }
  }
}
